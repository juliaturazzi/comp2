public class SenhaInvalidaException extends Exception {
}
