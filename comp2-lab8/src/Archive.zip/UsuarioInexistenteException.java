public class UsuarioInexistenteException extends Exception {
}
