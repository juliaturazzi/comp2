public interface Sorteador { int sortear(); }
