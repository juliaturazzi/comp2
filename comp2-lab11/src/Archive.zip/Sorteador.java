public interface Sorteador<T> {

    T sortear();
}
