package excecao;

public class LimiteEmprestimosExcedidoException extends Exception {
}
