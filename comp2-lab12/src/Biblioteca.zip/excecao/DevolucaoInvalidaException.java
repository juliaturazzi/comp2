package excecao;

public class DevolucaoInvalidaException extends Exception {
}
