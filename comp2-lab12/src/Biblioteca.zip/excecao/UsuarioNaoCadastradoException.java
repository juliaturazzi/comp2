package excecao;

public class UsuarioNaoCadastradoException extends Exception {
}
